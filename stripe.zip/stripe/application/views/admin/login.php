<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Admin Login</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

  </head>

  <body class="bg-dark">

    <div class="container">
    <div class="col-md-6">
      <div class="card card-login mx-auto mt-5">
        <div class="card-header">Admin Login</div>
        <!---- Error Message ---->

        <div class="card-body">
<?php echo form_open('login');?>
            <div class="form-group">
              <div class="form-label-group">
<?php echo form_input(['name'=>'username','id'=>'username','class'=>'form-control','autofocus'=>'autofocus','value'=>set_value('username')]);?>
<?php echo form_label('Enter Username', 'username'); ?>
<?php echo form_error('username',"<div style='color:red'>","</div>");?>
              </div>
            </div>
            <div class="form-group">
              <div class="form-label-group">
<?php echo form_password(['name'=>'password','id'=>'password','class'=>'form-control','autofocus'=>'autofocus','value'=>set_value('password')]);?>
<?php echo form_label('Password', 'password'); ?>
<?php echo form_error('password',"<div style='color:red'>","</div>");?>
              </div>
            </div>
   
 <?php echo form_submit(['name'=>'login','value'=>'Login','class'=>'btn btn-primary btn-block']); ?>
  <a class="d-block small"  href="<?php echo site_url('Welcome'); ?>">Back to Home page</a>
<?php echo form_close(); ?>
     
        </div>
      </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript-->
  

  </body>

</html>
