<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>View Details</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />

    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/style.css" />    

    <!-- jQuery is used only for this example; it isn't required to use Stripe -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" />

    <!-- Stripe JavaScript library -->
   
	
</head>
<body>


	


<div class="container">
	<div class="row">	

      

        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-info text-white">
                  User Subscription Details
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Name </th>
                                <th>Email</th>
                                <th>Subscription Id</th>
                                <th>Item Name</th>
                                <th>Item price</th>
                                <th>Status</th>
                                <th>Subscription Period</th>
                                 <th>Date</th>
                           
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <?php
                                if($details){
                                     foreach($details as $row) { ?>
                                 <td><?= $row['name'] ?></td>
                                 <td><?= $row['payer_email'] ?></td>
                                 <td><?= $row['stripe_subscription_id'] ?></td>
                                 <td><?= $row['plan_name'] ?></td>
                                 <td>₹<?= $row['plan_amount'] ?></td>
                                <td><?= $row['status'] ?></td>
                                 <td><?= $row['plan_interval_count'] ?> days</td>
                                 <td><?= $row['created'] ?></td>
                                 </tr>
                                 <?php } } else { ?>
                                    <td> No data found!</td>
                                <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>    
        </div>
       

      

    </div>
</div> 

<div class="col-md-4">
            <div class="card">
               
                <a class="card-footer  clearfix small z-1"  href="<?php echo site_url('login/logout'); ?>">
                  <span class="float-left">Logout</span>
                  <span class="float-right">
                    <i class="fas fa-angle-right"></i>
                  </span>
                </a>
            </div>    
        </div>
</body>
</html>