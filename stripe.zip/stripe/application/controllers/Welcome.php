<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	
	var $api_error;
	var $currency; 
	function __construct() { 
        parent::__construct(); 
		$this->api_error = ''; 
		$this->currency = 'INR'; 
		$this->load->model('Users_Model'); 
         
    } 

	public function index()
	{
		$data['plans'] = $this->Users_Model->getPlans(); 
		$this->load->view('product_form', $data);	
	}

	public function check()
	{
		
		//check whether stripe token is not empty
		if(!empty($_POST['stripeToken']))
		{
			//get token, card and user info from the form
			$token  = $_POST['stripeToken'];
			$name = $_POST['name'];
			$email = $_POST['email'];
			$card_num = $_POST['card_num'];
			$card_cvc = $_POST['cvc'];
			$card_exp_month = $_POST['exp_month'];
			$card_exp_year = $_POST['exp_year'];
			$plan_id = $_POST['subscr_plan'];
			$product_details = $this->Users_Model->getPlans($plan_id); 
			$planID = $_POST['subscr_plan']; 
            $planName = $product_details['name']; 
            $planPrice = $product_details['price']; 
            $planInterval = $product_details['interval']; 
             
			//include Stripe PHP library
			require_once APPPATH."third_party/stripe/init.php";
			
			//set api key
			$stripe = array(
			  "secret_key"      => "sk_test_********************",
			  "publishable_key" => "pk_test_********************"
			);
			
			\Stripe\Stripe::setApiKey($stripe['secret_key']);
			
			//add customer to stripe
			$customer = $this->addCustomer($name, $email, $token);
			//print_r($customer);die;

			if($customer){ 
				//create a charge
				$charge = $this->createCharge($customer->id, $product_details, $_POST); 
                // Create a plan 
                $plan = $this->createPlan($product_details['name'], $product_details['price'], $product_details['interval']); 
                 
                if($plan){ 
                    // Creates a new subscription 
                    $subscription = $this->createSubscription($customer->id, $plan->id); 
                   // print_r($subscription);die; 
                    if($subscription){ 
                        // Check whether the subscription activation is successful 
                        if($subscription['status']){ 
                            // Subscription info 
                            $subscrID = $subscription['id']; 
                            $custID = $subscription['customer']; 
                            $planID = $subscription['plan']['id']; 
                            $planAmount = ($subscription['plan']['amount']/100); 
                            $planCurrency = $subscription['plan']['currency']; 
                            $planInterval = $subscription['plan']['interval']; 
                            $planIntervalCount = $subscription['plan']['interval_count']; 
                            $created = date("Y-m-d H:i:s", $subscription['created']); 
                            $current_period_start = date("Y-m-d H:i:s", $subscription['current_period_start']); 
                            $current_period_end = date("Y-m-d H:i:s", $subscription['current_period_end']); 
                            $status = $subscription['status']; 
                             
                            // Insert tansaction data into the database 
							$userId = rand(10,100);
                            $subscripData = array( 
                                'user_id' => $userId, 
								'name' => $name,
                                'plan_id' => $product_details['id'], 
                                'stripe_subscription_id' => $subscrID, 
                                'stripe_customer_id' => $custID, 
                                'stripe_plan_id' => $planID, 
                                'plan_amount' => $planAmount, 
                                'plan_amount_currency' => $planCurrency, 
                                'plan_interval' => $planInterval, 
                                'plan_interval_count' => $planIntervalCount, 
                                'plan_period_start' => $current_period_start, 
                                'plan_period_end' => $current_period_end, 
                                'payer_email' => $email, 
                                'created' => $created, 
                                'status' => $status 
                            ); 
                            $subscription_id = $this->Users_Model->insertSubscription($subscripData); 
                             
                            // Update subscription id in the users table  
                            if($subscription_id && !empty($this->userID)){ 
                                $data = array('subscription_id' => $subscription_id); 
                                $update = $this->Users_Model->updateUser($data, $this->userID); 
                            } 
                             
                            return $subscription_id; 
                        } 
                    } 
                } 
            }
			
			
		}
	}

	public function payment_success()
	{
		$this->load->view('payment_success');
	}

	public function payment_error()
	{
		$this->load->view('payment_error');
	}

	function addCustomer($name, $email, $token){ 
        try { 
            // Add customer to stripe 
            $customer = \Stripe\Customer::create(array( 
                'name' => $name, 
                'email' => $email, 
                'source'  => $token 
            )); 
            return $customer; 
        }catch(Exception $e) { 
            $this->api_error = $e->getMessage(); 
            echo $this->api_error;
        } 
    } 
	function createCharge($customerId, $productDetails, $postArray){
		
		$token  = $postArray['stripeToken'];
			$name = $postArray['name'];
			$email = $postArray['email'];
			$card_num = $postArray['card_num'];
			$card_cvc = $postArray['cvc'];
			$card_exp_month = $postArray['exp_month'];
			$card_exp_year = $postArray['exp_year'];
			$plan_id = $postArray['subscr_plan'];
			$product_details = $this->Users_Model->getPlans($plan_id); 
		//charge a credit or a debit card
		try{
			$charge = \Stripe\Charge::create(array(
				'customer' => $customerId,
				'amount'   => $productDetails['price'],
				'currency' => $this->currency,
				'description' => $productDetails['name'],
				'metadata' => array(
					'item_id' => $productDetails['name'],
				)
			));
		 
		
		
		//retrieve charge details
		$chargeJson = $charge->jsonSerialize();

		//check whether the charge is successful
		if($chargeJson['amount_refunded'] == 0 && empty($chargeJson['failure_code']) && $chargeJson['paid'] == 1 && $chargeJson['captured'] == 1)
		{
			//order details 
			$amount = $chargeJson['amount'];
			$balance_transaction = $chargeJson['balance_transaction'];
			$currency = $chargeJson['currency'];
			$status = $chargeJson['status'];
			$date = date("Y-m-d H:i:s");
		
			
			//insert tansaction data into the database
			$dataDB = array(
				'name' => $name,
				'email' => $email, 
				'card_num' => $card_num, 
				'card_cvc' => $card_cvc, 
				'card_exp_month' => $card_exp_month, 
				'card_exp_year' => $card_exp_year, 
				'item_name' => $productDetails['name'], 
				'item_number' => $productDetails['id'], 
				'item_price' => $productDetails['price'], 
				'item_price_currency' => $currency, 
				'paid_amount' => $amount, 
				'paid_amount_currency' => $currency, 
				'txn_id' => $balance_transaction, 
				'payment_status' => $status,
				'created' => $date,
				'modified' => $date
			);

			if ($this->db->insert('orders', $dataDB)) {
				if($this->db->insert_id() && $status == 'succeeded'){
					$data['insertID'] = $this->db->insert_id();
					$this->load->view('payment_success', $data);
				}else{
					echo "Transaction has been failed";
				}
			}
			else
			{
				echo "not inserted. Transaction has been failed";
			}

		}
		else
		{
			echo "Invalid Token";
			$statusMsg = "";
		}
	}catch(Exception $e) { 
		$this->api_error = $e->getMessage(); 
		echo $this->api_error;
	} 
	}
     
    function createPlan($planName, $planPrice, $planInterval){ 
        // Convert price to cents 
        $priceCents = ($planPrice*100); 
        $currency = $this->currency;
         
        try { 
            // Create a plan 
            $plan = \Stripe\Plan::create(array( 
                "product" => [ 
                    "name" => $planName 
                ], 
                "amount" => $priceCents, 
                "currency" => $currency, 
                "interval" => 'day', 
                "interval_count" => 30 
            )); 
            return $plan; 
        }catch(Exception $e) { 
            $this->api_error = $e->getMessage(); 
            echo $this->api_error;
        } 
    } 
     
    function createSubscription($customerID, $planID){ 
        try { 
            // Creates a new subscription 
            $subscription = \Stripe\Subscription::create(array( 
                "customer" => $customerID, 
                "items" => array( 
                    array( 
                        "plan" => $planID 
                    ), 
                ), 
            ));
		   
            // Retrieve charge details 
            $subsData = $subscription->jsonSerialize(); 
			return $subsData;
        }catch(Exception $e) { 
            $this->api_error = $e->getMessage(); 
			echo $this->api_error;
        } 
    } 
}
